import javax.swing.JOptionPane;

public class SimpleCalculator 
{

	public static void main(String[] args) 
	{
		String num = JOptionPane.showInputDialog("Enter a number");
		double numa = Float.parseFloat(num);
		num = JOptionPane.showInputDialog("Enter a number");
		double numb = Float.parseFloat(num);
		
		JOptionPane.showInternalMessageDialog(null, numa + "+" + numb + "=" + (numa + numb));
		JOptionPane.showInternalMessageDialog(null, numa + "-" + numb + "=" + (numa - numb));
		JOptionPane.showInternalMessageDialog(null, numb + "-" + numa + "=" + (numb - numa));
		JOptionPane.showInternalMessageDialog(null, numa + "*" + numb + "=" + (numa * numb));
		JOptionPane.showInternalMessageDialog(null, numa + "/" + numb + "=" + (numa / numb));
		JOptionPane.showInternalMessageDialog(null, numb + "/" + numa + "=" + (numb / numa));
		

	}

}
