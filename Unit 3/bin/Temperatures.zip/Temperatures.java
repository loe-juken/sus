import java.util.Scanner;
public class Temperatures 
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.print("What is today's high temperature? ");
		double highTemp = input.nextFloat();
		System.out.print("What is today's low temperature? ");
		double lowTemp = input.nextFloat();
		
		if (highTemp >= 90) System.out.println("HEAT WARNING!");
		if (lowTemp < 32) System.out.println("FREEZE WARNING!");
		if (highTemp - lowTemp > 40) System.out.println("Large temperature swing");

	}

}
