import java.util.*;
public class QuadraticFormula 
{

	public static void main(String[] args) 
	{
		Scanner sus = new Scanner(System.in);
		
		System.out.println("Enter your coefficients in order");
		double coef1 = Double.parseDouble(sus.nextLine());
		double coef2 = Double.parseDouble(sus.nextLine());
		double coef3 = Double.parseDouble(sus.nextLine());
		
		double top1 = -coef1 + (Math.sqrt(Math.pow(coef2, 2) - 4*coef1*coef3));
		double top2 = -coef1 - (Math.sqrt(Math.pow(coef2, 2) - 4*coef1*coef3));
		
		System.out.println("Equation - " + coef1 + "x^2 + " + coef2 + "x + " + coef3);
		if ((Math.sqrt(Math.pow(coef2, 2) - 4*coef1*coef3))<0)
		{
			System.out.println("There are no real solutions");
		}
		else System.out.println("Roots - " + top1/(2*coef1) + " and " + top2/(2*coef1));
		
		
	}
		

		
}
